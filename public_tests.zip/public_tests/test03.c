#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main() {
  int control;
  char buf[64];

  control = 3;
  fgets(buf, 77, stdin);

}