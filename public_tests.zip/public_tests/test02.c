#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main() {
  int control;
  char buf[64];

  control = 2;
  fgets(buf, 65, stdin);

}